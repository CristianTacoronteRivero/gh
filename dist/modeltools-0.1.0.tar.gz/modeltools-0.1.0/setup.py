# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['modeltools']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'modeltools',
    'version': '0.1.0',
    'description': '',
    'long_description': 'Este es nuestro primer proyecto con CI/CD',
    'author': 'CristianTacoronteRivero',
    'author_email': 'cristiantr.develop@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
